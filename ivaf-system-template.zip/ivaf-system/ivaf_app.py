import streamlit as st
import datetime
# from ivaf_flow import flow, save_today_log

st.set_page_config(page_title="IVAF - 나의 내면 대화", page_icon="🌌")
st.title("🌌 IVAF InnerVerse 에이전트")
st.write("의식과 무의식, 우주적 자아와의 일일 대화 공간")

user_input = st.text_area("📝 오늘의 질문이나 생각을 입력해 주세요")

if st.button("✨ 내면 탐색 시작"):
    if user_input:
        with st.spinner("NOVA와 BERKA가 작업 중..."):
            # Dummy result
            st.success("🚀 결과 생성 완료!")
            st.markdown("**최종 통합 결과:**\n\n이곳에 NOVA와 BERKA의 결과가 표시됩니다.")
            st.info("📄 오늘의 대화 기록이 저장되었습니다.")
    else:
        st.warning("⚠️ 질문이나 생각을 입력해 주세요.")