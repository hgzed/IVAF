# IVAF (InnerVerse Agent Framework)

🌌 내면과 현실을 연결하는 멀티 에이전트 시스템

## 구성 요소
- LangGraph 기반 에이전트 플로우
- Pinecone 무의식 데이터 연동
- Supabase 대화 기록 저장
- Streamlit 대화형 UI

## 배포 방법
1. `.env` 대신 Streamlit Secrets 사용
2. Streamlit Cloud에서 GitHub 저장소 연결 후 배포