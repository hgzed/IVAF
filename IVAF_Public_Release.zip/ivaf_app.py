import streamlit as st
from ivaf_flow import run_ivaf_flow

st.set_page_config(page_title="IVAF", page_icon="🌌")

st.title("IVAF - 나와 무의식의 대화")

user_input = st.text_input("오늘 당신의 질문을 입력하세요:")

if st.button("대화 시작") and user_input:
    with st.spinner("내면 에이전트 작업 중..."):
        result = run_ivaf_flow(user_input)
    st.success("내면 리포트 생성 완료")
    st.write(result)
