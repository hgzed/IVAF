# IVAF Beginner's Guide

IVAF는 인간의 의식과 무의식을 연결하는 AI 프레임워크입니다.

## 주요 개념
- Supervisor
- NOVA
- BERKA
- Task Agents
