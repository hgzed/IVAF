import os
import openai
from supabase_client import log_user_interaction
from pinecone_memory import store_memory

openai.api_key = os.getenv("OPENAI_API_KEY")

def run_ivaf_flow(user_input):
    try:
        system_prompt = "NOVA 에이전트로서 사용자의 내면 리포트를 작성하세요."
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_input}
            ]
        )
        result = response["choices"][0]["message"]["content"]
        log_user_interaction(user_input, result)
        store_memory(user_input, result)
        return result
    except Exception as e:
        return f"에러 발생: {str(e)}"
