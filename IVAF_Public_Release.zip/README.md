# IVAF - InnerVerse Agent Framework

IVAF는 인간의 의식과 무의식을 연결하는 오픈소스 AI 에이전트 시스템입니다.

## 빠른 시작
```bash
git clone https://github.com/your-username/IVAF-Public.git
cd IVAF-Public
bash setup.sh
```

## 주요 기능
- Streamlit 기반 대화형 인터페이스
- Supabase 로그 저장
- Pinecone 기억 저장 및 검색

## 라이선스
MIT License - by 최철환 (Chulhwan Choi)
