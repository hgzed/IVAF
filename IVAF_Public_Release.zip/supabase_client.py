from supabase import create_client
import os
from dotenv import load_dotenv

load_dotenv()

supabase = create_client(os.getenv("SUPABASE_URL"), os.getenv("SUPABASE_KEY"))

def log_user_interaction(user_input, result):
    data = {"user_input": user_input, "result": result}
    try:
        supabase.table("ivaf_logs").insert(data).execute()
    except Exception as e:
        print(f"Supabase 저장 오류: {str(e)}")
