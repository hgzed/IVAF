#!/bin/bash
pip install -r requirements.txt
streamlit run ivaf_app.py
