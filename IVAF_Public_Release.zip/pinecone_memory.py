import os
import pinecone
from uuid import uuid4
from dotenv import load_dotenv

load_dotenv()

pinecone.init(api_key=os.getenv("PINECONE_API_KEY"), environment="us-west1-gcp")
index = pinecone.Index(os.getenv("PINECONE_INDEX"))

def store_memory(user_input, result):
    from openai.embeddings_utils import get_embedding
    text = f"{user_input}\n{result}"
    vector = get_embedding(text, engine="text-embedding-ada-002")
    index.upsert([(str(uuid4()), vector, {"text": text})])
